Online Book Store using HTML, JavaScript, Java Servlet, and SQL. Built with my team member for a school project. I was the front-end developer. 
