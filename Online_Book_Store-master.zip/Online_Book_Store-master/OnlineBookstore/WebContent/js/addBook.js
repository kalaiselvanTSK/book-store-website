// Changes a p tag in the addbook page.
$(document).ready(function loadAddBook() {
	$("#bookMessage").text("");
});