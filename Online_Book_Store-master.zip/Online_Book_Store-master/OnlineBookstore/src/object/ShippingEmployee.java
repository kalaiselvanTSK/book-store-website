package object;

/*
Creates a Shipping Employee Object
*/

public class ShippingEmployee extends User{

}
